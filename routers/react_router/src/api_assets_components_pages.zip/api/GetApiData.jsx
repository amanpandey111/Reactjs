export const getMoviesData = async()=> {
     try {
        const res = await fetch('https://www.omdbapi.com/?s=guardians&apikey=c1ae2c28')
        const data = await res.json()
        return data
     } catch (error) {
        console.log(error);
     }
}
