const Loading = () => {
  return (
    <div>
        <h1>Loading...</h1>
        <img src="https://cdn.pixabay.com/animation/2024/07/27/09/34/09-34-07-906_512.gif" alt="" />
    </div>
  )
}

export default Loading