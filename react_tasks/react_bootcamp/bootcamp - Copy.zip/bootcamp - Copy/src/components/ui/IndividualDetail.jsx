
export const individualDetail = ({params}) => {
    console.log(params.id);
    return params.id
}